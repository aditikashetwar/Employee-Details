package com.example.MyProject;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {

	
	@Autowired
	public EmployeeService es;
	
	@RequestMapping("fetchemployeedata")
	public void setDataInDB() {
		es.saveEmployeeData();
	}
	
	List<Employee>arraylist;
	@Autowired
	SessionFactory sessionfactory;
	@RequestMapping("getallemployeedata")
	public List<Employee>getAllEmployeeData() {
		Session session=sessionfactory.openSession();
		
		List<Employee> employee=session.createCriteria(Employee.class).list();
		return employee;
	}
		
	}




