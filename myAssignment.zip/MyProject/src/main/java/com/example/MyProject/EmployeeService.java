package com.example.MyProject;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;


@Service
public class EmployeeService {
	
	@Autowired
	public EmployeeDTO cdto;
	
	String line=""; 
	public void saveEmployeeData() {
		try {
			
			BufferedReader br=new BufferedReader(new FileReader("src/main/resources/EmployeeDetails1.csv"));
			while((line=br.readLine())!=null)
			{
				String []data=line.split(",");
				
				Employee e= new Employee();
				e.setName(data[0]);
				e.setAge(data[1]);
				e.setGender(data[2]);
				e.setAddress(data[3]);
				e.setCity(data[4]);
				
				cdto.save(e);
				
			}
			}catch(IOException e) {
				e.printStackTrace();			}
	}
		

}
